
import os
import threading
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Updater, CommandHandler, CallbackQueryHandler, MessageHandler, Filters, CallbackContext

BOT_TOKEN = os.getenv("BOT_TOKEN")
QR_IMAGE = "qr_code.png"
APP_FILE = "FakePhonePe.apk"
ADMIN_ID = os.getenv("ADMIN_ID")  # Your Telegram user ID

pending_users = {}
sent_messages = {}

def start(update: Update, context: CallbackContext):
    keyboard = [[InlineKeyboardButton("Buy", callback_data='buy')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    msg = context.bot.send_message(chat_id=update.effective_chat.id, text="Welcome! Click Buy to proceed.", reply_markup=reply_markup)
    track_message(update.effective_chat.id, msg.message_id)

def buy_callback(update: Update, context: CallbackContext):
    query = update.callback_query
    query.message.delete()
    msg = context.bot.send_photo(
        chat_id=query.message.chat_id,
        photo=open(QR_IMAGE, 'rb'),
        caption="Scan and pay ₹99 via PhonePe.

After payment, send screenshot here.

Fake UTR = Block."
    )
    track_message(query.message.chat_id, msg.message_id)

def handle_screenshot(update: Update, context: CallbackContext):
    user_id = update.effective_user.id
    pending_users[user_id] = update.message.message_id

    # Forward to admin
    caption = f"Payment proof from user: {user_id}"
    if update.message.photo:
        context.bot.forward_message(chat_id=ADMIN_ID, from_chat_id=user_id, message_id=update.message.message_id)
        context.bot.send_message(chat_id=ADMIN_ID, text=caption + "\nReply with /approve to send the file.")
    else:
        context.bot.send_message(chat_id=user_id, text="Please send a screenshot/photo of the payment.")

def approve(update: Update, context: CallbackContext):
    if str(update.effective_user.id) != ADMIN_ID:
        update.message.reply_text("Unauthorized.")
        return

    if not update.message.reply_to_message:
        update.message.reply_text("Please reply to the forwarded message to approve.")
        return

    original_msg = update.message.reply_to_message
    text = original_msg.caption or ""
    user_id = None

    for word in text.split():
        if word.isdigit():
            user_id = int(word)
            break

    if user_id:
        msg = context.bot.send_document(chat_id=user_id, document=open(APP_FILE, 'rb'), filename="FakePhonePe.apk", caption="Thanks! Here is your app.")
        track_message(user_id, msg.message_id)
        update.message.reply_text("File sent to user.")
        # Start deletion thread
        threading.Thread(target=schedule_deletion, args=(context, user_id), daemon=True).start()
    else:
        update.message.reply_text("Could not find user ID.")

def track_message(chat_id, message_id):
    if chat_id not in sent_messages:
        sent_messages[chat_id] = []
    sent_messages[chat_id].append(message_id)

def schedule_deletion(context: CallbackContext, chat_id: int):
    time.sleep(300)  # 5 minutes
    if chat_id in sent_messages:
        for msg_id in sent_messages[chat_id]:
            try:
                context.bot.delete_message(chat_id=chat_id, message_id=msg_id)
            except:
                pass
        sent_messages[chat_id] = []
        try:
            context.bot.send_message(chat_id=chat_id, text="Session expired. Please /start again.")
        except:
            pass

def main():
    updater = Updater(BOT_TOKEN)
    dp = updater.dispatcher

    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(CallbackQueryHandler(buy_callback, pattern='buy'))
    dp.add_handler(CommandHandler("approve", approve))
    dp.add_handler(MessageHandler(Filters.photo, handle_screenshot))

    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()
